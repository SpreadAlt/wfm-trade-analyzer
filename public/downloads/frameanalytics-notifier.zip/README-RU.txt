FrameAnalytics Notifier для Windows
==================================

Назначение
----------
Программа живёт в системном трее и показывает уведомления, даже когда сайт
FrameAnalytics закрыт. Она сообщает о новых возможностях перепродажи и о
результатах Axi-сканера с соотношением от 10x.

Первый запуск
-------------
1. Запустите Start-FrameAnalyticsNotifier.cmd.
2. В трее Windows появится иконка FrameAnalytics.
3. Нажмите по ней правой кнопкой -> «Настройки».
4. Вставьте значение секрета DESKTOP_NOTIFY_TOKEN вместо
   PASTE_DESKTOP_NOTIFY_TOKEN_HERE и сохраните файл.
5. Нажмите «Проверить сейчас» в меню иконки.

Важно: DESKTOP_NOTIFY_TOKEN — отдельный длинный случайный секрет. Он не должен
совпадать с ADMIN_KEY, BETA_ADMIN_KEY, SMART_BUY_START_SECRET или ключом
Warframe Market. Не отправляйте notifier.json другим людям.

Автозапуск
----------
Запустите Install-Autostart.ps1. Для отключения используйте
Remove-Autostart.ps1.

Где хранятся настройки
----------------------
%LOCALAPPDATA%\FrameAnalytics\notifier.json
%LOCALAPPDATA%\FrameAnalytics\notifier-seen.json

Остановка
---------
Нажмите правой кнопкой по иконке в трее и выберите «Выход».

