﻿param(
  [switch]$CheckOnce
)

$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$AppDirectory = Join-Path $env:LOCALAPPDATA "FrameAnalytics"
$ConfigPath = Join-Path $AppDirectory "notifier.json"
$SeenPath = Join-Path $AppDirectory "notifier-seen.json"
$SiteUrl = "https://frameanalytics.trade/profile"
$Script:LastUrl = $SiteUrl
$Script:Polling = $false
$Script:Seen = @{}

New-Item -ItemType Directory -Path $AppDirectory -Force | Out-Null

function Write-DefaultConfig {
  if (Test-Path $ConfigPath) { return }
  [ordered]@{
    endpoint = "https://frameanalytics.trade/api/desktop-notifications/feed"
    token = "PASTE_DESKTOP_NOTIFY_TOKEN_HERE"
    pollSeconds = 10
  } | ConvertTo-Json | Set-Content -Path $ConfigPath -Encoding UTF8
}

function Read-NotifierConfig {
  Write-DefaultConfig
  $value = Get-Content -Raw -Path $ConfigPath | ConvertFrom-Json
  $endpoint = [string]$value.endpoint
  $token = [string]$value.token
  $requestedPollSeconds = [int]$value.pollSeconds
  # Migrate the old default without touching custom intervals.
  if ($requestedPollSeconds -eq 60) { $requestedPollSeconds = 10 }
  $pollSeconds = [Math]::Max(5, [Math]::Min(900, $requestedPollSeconds))
  return [PSCustomObject]@{ endpoint = $endpoint.Trim(); token = $token.Trim(); pollSeconds = $pollSeconds }
}

function Load-SeenNotifications {
  if (-not (Test-Path $SeenPath)) { return }
  try {
    $values = @(Get-Content -Raw -Path $SeenPath | ConvertFrom-Json)
    foreach ($value in $values) {
      if ($value) { $Script:Seen[[string]$value] = $true }
    }
  } catch {
    $Script:Seen = @{}
  }
}

function Save-SeenNotifications {
  @($Script:Seen.Keys | Select-Object -Last 1000) | ConvertTo-Json | Set-Content -Path $SeenPath -Encoding UTF8
}

function Open-Url([string]$Url) {
  if ([string]::IsNullOrWhiteSpace($Url)) { $Url = $SiteUrl }
  Start-Process $Url
}

$NotifyIcon = New-Object System.Windows.Forms.NotifyIcon
$NotifyIcon.Icon = [System.Drawing.SystemIcons]::Information
$NotifyIcon.Text = "FrameAnalytics notifications"
$NotifyIcon.Visible = $true

function Show-TrayMessage([string]$Title, [string]$Body, [string]$Url = $SiteUrl, [int]$Timeout = 10000) {
  $Script:LastUrl = $Url
  $NotifyIcon.BalloonTipTitle = $Title
  $NotifyIcon.BalloonTipText = $Body
  $NotifyIcon.BalloonTipIcon = [System.Windows.Forms.ToolTipIcon]::Info
  $NotifyIcon.ShowBalloonTip($Timeout)
}

function Poll-Notifications {
  if ($Script:Polling) { return }
  $Script:Polling = $true
  try {
    $config = Read-NotifierConfig
    if (-not $config.endpoint -or -not $config.token -or $config.token -eq "PASTE_DESKTOP_NOTIFY_TOKEN_HERE") {
      Show-TrayMessage "FrameAnalytics" "Откройте настройки и вставьте DESKTOP_NOTIFY_TOKEN." $ConfigPath
      return
    }
    $headers = @{ Authorization = "Bearer $($config.token)"; Accept = "application/json" }
    $feed = Invoke-RestMethod -Method Get -Uri $config.endpoint -Headers $headers -TimeoutSec 25
    $newItems = @($feed.notifications | Where-Object { $_.id -and -not $Script:Seen.ContainsKey([string]$_.id) })
    if ($newItems.Count -eq 0) { return }
    foreach ($item in $newItems) { $Script:Seen[[string]$item.id] = $true }
    Save-SeenNotifications
    if ($newItems.Count -eq 1) {
      $item = $newItems[0]
      Show-TrayMessage ([string]$item.title) ([string]$item.body) ([string]$item.url)
    } else {
      $preview = @($newItems | Select-Object -First 3 | ForEach-Object { [string]$_.title }) -join "; "
      Show-TrayMessage "FrameAnalytics: $($newItems.Count) новых сигналов" $preview $SiteUrl
    }
  } catch {
    Show-TrayMessage "FrameAnalytics: ошибка уведомлений" $_.Exception.Message $ConfigPath 8000
  } finally {
    $Script:Polling = $false
  }
}

Load-SeenNotifications

if ($CheckOnce) {
  Poll-Notifications
  $NotifyIcon.Dispose()
  exit 0
}

$Menu = New-Object System.Windows.Forms.ContextMenuStrip
$OpenItem = $Menu.Items.Add("Открыть FrameAnalytics")
$CheckItem = $Menu.Items.Add("Проверить сейчас")
$SettingsItem = $Menu.Items.Add("Настройки")
$ExitItem = $Menu.Items.Add("Выход")
$OpenItem.add_Click({ Open-Url $SiteUrl })
$CheckItem.add_Click({ Poll-Notifications })
$SettingsItem.add_Click({ Write-DefaultConfig; Start-Process notepad.exe $ConfigPath })
$ExitItem.add_Click({
  $Timer.Stop()
  $NotifyIcon.Visible = $false
  $NotifyIcon.Dispose()
  [System.Windows.Forms.Application]::Exit()
})
$NotifyIcon.ContextMenuStrip = $Menu
$NotifyIcon.add_DoubleClick({ Open-Url $SiteUrl })
$NotifyIcon.add_BalloonTipClicked({ Open-Url $Script:LastUrl })

$Config = Read-NotifierConfig
$Timer = New-Object System.Windows.Forms.Timer
$Timer.Interval = [Math]::Max(5000, $Config.pollSeconds * 1000)
$Timer.add_Tick({ Poll-Notifications })
$Timer.Start()

Poll-Notifications
[System.Windows.Forms.Application]::Run()
