FrameAnalytics Notifier для Windows
==================================

Назначение
----------
Программа живёт в системном трее и показывает уведомления, даже когда сайт
FrameAnalytics закрыт. Она сообщает о новых возможностях перепродажи и о
результатах Axi/Prime Set, прошедших выбранный в сканере порог наценки.

Первый запуск
-------------
1. Запустите Start-FrameAnalyticsNotifier.cmd.
2. В трее Windows появится иконка FrameAnalytics.
3. Нажмите по ней правой кнопкой -> «Настройки».
4. Вставьте значение секрета DESKTOP_NOTIFY_TOKEN вместо
   PASTE_DESKTOP_NOTIFY_TOKEN_HERE и сохраните файл.
5. Нажмите «Проверить сейчас» в меню иконки.

По умолчанию клиент проверяет новые сигналы каждые 10 секунд. Интервал можно
изменить через pollSeconds в notifier.json; минимальное значение — 5 секунд.

Важно: DESKTOP_NOTIFY_TOKEN — отдельный длинный случайный секрет. Он не должен
совпадать с ADMIN_KEY, BETA_ADMIN_KEY, SMART_BUY_START_SECRET или ключом
Warframe Market. Не отправляйте notifier.json другим людям.

Автозапуск
----------
Запустите Install-Autostart.ps1. Для отключения используйте
Remove-Autostart.ps1.

Где хранятся настройки
----------------------
%LOCALAPPDATA%\FrameAnalytics\notifier.json
%LOCALAPPDATA%\FrameAnalytics\notifier-seen.json

Остановка
---------
Нажмите правой кнопкой по иконке в трее и выберите «Выход».
