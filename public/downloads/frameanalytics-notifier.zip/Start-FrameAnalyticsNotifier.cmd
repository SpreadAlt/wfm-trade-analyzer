@echo off
start "FrameAnalytics Notifier" powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "%~dp0FrameAnalyticsNotifier.ps1"

