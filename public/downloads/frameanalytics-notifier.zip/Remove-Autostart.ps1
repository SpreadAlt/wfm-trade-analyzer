$ShortcutPath = Join-Path ([Environment]::GetFolderPath("Startup")) "FrameAnalytics Notifier.lnk"
if (Test-Path $ShortcutPath) {
  Remove-Item -LiteralPath $ShortcutPath -Force
  Write-Host "Автозапуск отключён." -ForegroundColor Green
} else {
  Write-Host "Ярлык автозапуска не найден."
}

